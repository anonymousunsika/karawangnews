<?php
$db = mysqli_connect("localhost", "root", "", "gamestore") or die("Could not connect: " . mysqli_error($db));
